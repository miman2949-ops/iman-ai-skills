---
title: "Writing Scientific Article"
source_file: "Writing Scientific Article.pptx"
source_type: "PowerPoint presentation"
author_as_listed: "Hirshi Anadza, M.Hub.Int"
language: "English with Indonesian examples"
purpose: "Reference material for planning and writing scientific articles"
---

# Writing Scientific Article

> **Catatan konversi:** Dokumen ini disusun dari teks dan elemen visual yang dapat dibaca pada slide. Beberapa slide berisi contoh artikel dalam bentuk gambar. Bagian tersebut dijelaskan berdasarkan struktur visualnya; teks kecil yang tidak terbaca tidak direka ulang.

## 1. Introduction: tujuan dan sikap dalam penulisan artikel

Materi memandang penulisan artikel ilmiah yang dipublikasikan sebagai upaya membangun sejarah melalui tradisi akademik.

Menulis untuk jurnal memerlukan perubahan sikap dan tradisi akademik:

- Dari otoritas penulis menuju otoritas editor.
- Dari selera pribadi menuju karakter atau ketentuan jurnal.
- Dari pekerjaan individual menuju kontribusi yang dapat dibaca dan dinilai secara umum.
- Penulisan harus didasarkan pada data, bukan cerita pribadi tentang suatu fenomena.

Tujuan menulis artikel yang disebutkan dalam materi:

- Membangun reputasi akademik.
- Melakukan persuasi melalui tulisan ilmiah.

## 2. The Journal: memilih jurnal tujuan

Sebelum menulis atau mengirim artikel, penulis perlu mengenali jurnal tujuan.

### 2.1 Sumber untuk memeriksa indeksasi jurnal

Materi mencantumkan situs berikut:

- Scopus Sources: https://www.scopus.com/sources
- SINTA: https://sinta.kemdiktisaintek.go.id/journals
- DOAJ: https://doaj.org/
- BISON: https://service.tib.eu/bison/

**Catatan penggunaan:** daftar situs di atas adalah sumber yang dicantumkan dalam materi. Status indeksasi jurnal harus diperiksa kembali pada situs resminya pada saat akan mengirim artikel karena status dapat berubah.

### 2.2 Informasi yang perlu diperiksa dari jurnal

Periksa unsur-unsur berikut:

1. **About Journal** — profil dan informasi umum jurnal.
2. **Author Fee/Charge (APC)** — biaya publikasi atau Article Processing Charge.
3. **Aim and Scope** — cakupan topik dan bidang yang diterima.
4. **Template** — format naskah yang diwajibkan.
5. **How to publish** — mekanisme pengiriman, misalnya melalui OJS atau email.
6. **Annual Publication** — bulan atau jadwal penerbitan tahunan.
7. **Number of articles per publication** — jumlah artikel dalam setiap edisi.
8. **Character of article** — karakteristik atau jenis artikel yang diterbitkan.

Prinsip praktis: jangan memilih jurnal hanya berdasarkan nama atau indeksasinya. Cocokkan topik, cakupan, format, biaya, dan proses pengirimannya.

## 3. The Topic: menemukan tema dan topik

### 3.1 Membaca untuk menemukan topik

Materi menekankan bahwa semakin banyak penulis membaca, semakin mudah penulis menemukan topik. Ide dapat berasal dari berbagai hal.

Tema yang ditampilkan sebagai contoh dalam materi:

- Human Rights.
- International Political Economy.
- Strategy and Security.
- Diplomacy and Negotiation.
- Global Issues.

Tema-tema tersebut merupakan contoh dari materi, bukan daftar bidang yang wajib dipilih.

### 3.2 Pendekatan deduktif, induktif, dan hybrid

Materi menampilkan tiga kemungkinan alur berpikir:

- **Deductive:** berangkat dari teori, kemudian melihat bukti empiris.
- **Inductive:** berangkat dari bukti empiris, kemudian membangun atau mengembangkan pemahaman teoretis.
- **Hybrid:** menggabungkan gerak teori dan bukti empiris.

Materi juga menegaskan: pilihan topik tidak dengan sendirinya menentukan jenis penelitian.

### 3.3 Mengubah pertanyaan menjadi pesan atau klaim artikel

Materi membedakan judul/topik yang hanya berbentuk pertanyaan atau deskripsi dengan topik yang menyampaikan pesan utama.

| Formulasi awal (pertanyaan/topik) | Formulasi pesan yang dituju dalam materi |
|---|---|
| Ukrainian Status in Bali after Russia’s Invasion | Bahwa status pengungsi warga Ukraina di Bali telah hilang dan mereka diperlakukan sebagai wisatawan. |
| Women Position in International Public Realm | Bahwa posisi perempuan dalam ranah publik internasional semakin strategis. |
| Europe’s Treatment of Refugees from Outside Europe | Bahwa Eropa menerapkan standar ganda dalam memperlakukan pengungsi dari luar Eropa. |
| Relations Between Nation-State in Dealing with Covid-19 | Bahwa kepentingan nasional tetap menjadi pertimbangan utama negara meskipun dunia menghadapi musuh bersama, yaitu Covid-19. |

**Cara membaca tabel:** contoh-contoh ini menunjukkan arah argumentasi yang ingin dibangun oleh penulis. Contoh tersebut bukan fakta yang otomatis benar; klaim dalam artikel nyata tetap harus diuji dengan bukti dan literatur.

### 3.4 Tiga elemen penting dalam penguasaan topik

Materi menyebut tiga elemen:

1. **Disciplinarity** — pemahaman mendalam terhadap topik dalam disiplin ilmu yang relevan.
2. **Criticality** — kemampuan berpikir kritis terhadap dialog ilmiah yang sedang berlangsung.
3. **Positionality** — kemampuan mengambil posisi dalam dialog ilmiah.

Ketiganya membantu penulis memahami topik, menilai perdebatan akademik, dan menjelaskan posisi artikelnya.

## 4. Menggunakan AI dalam penulisan ilmiah

Materi memberikan prinsip yang tegas:

- Gunakan AI sebagai **writing assistant**, bukan **ghostwriter**.
- Artikel ilmiah harus tetap merupakan karya penulis sendiri.

Implikasi praktis:

- AI dapat membantu mendiskusikan topik, mengorganisasi gagasan, memperjelas struktur, dan memeriksa bahasa.
- Penulis tetap bertanggung jawab atas pertanyaan penelitian, data, analisis, interpretasi, argumentasi, dan keaslian naskah.
- Jangan menerima referensi, data, atau klaim dari AI tanpa pemeriksaan.

## 5. Writing: kebiasaan dan persiapan menulis

Materi menghubungkan kegiatan membaca, kerangka tulisan, sumber, dan ide sebagai bagian dari proses menulis.

Saran kebiasaan menulis yang tercantum:

- Menulis maksimal 25 menit setiap hari.
- Menulis ketika pikiran masih segar (materi menyebut pagi hari sebagai contoh).
- Mematikan atau mengurangi distraksi.
- Menggunakan template jurnal sejak awal.
- Membaca sebagai bagian penting dari proses menulis.

## 6. Struktur artikel: IMRD/IMRAD

Materi menampilkan struktur utama:

1. Introduction.
2. Method/Methodology.
3. Result.
4. Discussion.

Materi juga mencantumkan elemen tambahan:

- Title.
- Authors and affiliation.
- Abstract.
- Conclusion.
- References.
- Acknowledge/Acknowledgement.

**Catatan:** materi menggunakan istilah IMRD pada slide. Template manuskrip yang menyertai materi memisahkan Literature Review dan Conclusion sebagai bagian tersendiri. Struktur akhir harus mengikuti jenis artikel dan ketentuan jurnal tujuan.

## 7. Introduction: membangun alasan penelitian

### 7.1 Tujuan Introduction

Introduction harus menunjukkan bahwa penelitian:

- Penting.
- Menarik.
- Memiliki masalah yang layak diteliti.
- Relevan.

Materi menyarankan menunjukkan hal tersebut dengan menyebutkan dan meninjau penelitian sebelumnya.

### 7.2 Tiga pekerjaan utama dalam Introduction

**A. Focus of Study**

Tunjukkan fokus penelitian dan alasan topik penting, menarik, bermasalah, serta relevan. Gunakan konteks dan penelitian terdahulu.

**B. Identifying Gap**

Uji dan kritik celah dalam penelitian terdahulu berdasarkan pengetahuan penulis. Gap tidak cukup hanya dinyatakan; perlu ditunjukkan melalui pembacaan literatur.

**C. Responding to the Gap**

Respons terhadap gap dapat mencakup:

- Research objectives.
- Research problem.
- Estimated research results atau perkiraan jawaban/arah temuan.
- Research value.
- Article structure.

### 7.3 Komposisi Introduction: Social Fact – Literature – Objection – Argument

Materi memberikan empat komponen:

#### 7.3.1 Social Fact

Isi konteks fenomena yang diteliti. Gunakan fakta atau data pendukung yang relevan dan dapat dirujuk.

Pertanyaan panduan:
- Fenomena apa yang sedang terjadi?
- Di mana dan kapan konteksnya?
- Data apa yang menunjukkan bahwa fenomena tersebut penting?

#### 7.3.2 Literature

Jelaskan jawaban atau penjelasan yang selama ini diberikan oleh penelitian terdahulu.

Pertanyaan panduan:
- Bagaimana fenomena ini dijelaskan oleh literatur?
- Pendekatan atau temuan apa yang sudah tersedia?
- Apa pola pemahaman yang dominan?

#### 7.3.3 Objection

Tunjukkan keberatan, keterbatasan, atau sudut pandang yang belum cukup dijelaskan oleh penjelasan terdahulu. Materi menyebut keunikan artikel dan perkiraan jawaban sebagai tujuan bagian ini.

Pertanyaan panduan:
- Apa yang belum dijelaskan?
- Apa yang perlu dikritisi atau diuji?
- Mengapa penjelasan yang tersedia belum cukup?

#### 7.3.4 Argument

Tuliskan logika atau dasar pemikiran bagi jawaban sementara/argumen yang ditawarkan.

Pertanyaan panduan:
- Apa posisi atau argumen utama penulis?
- Apa dasar logisnya?
- Bagaimana argumen itu akan dijelaskan dalam artikel?

### 7.4 Contoh visual pada slide

Materi menampilkan contoh Introduction tentang status pengungsi Ukraina di Bali dan konflik Israel–Palestina. Pada contoh Israel–Palestina, alurnya diperlihatkan sebagai:

1. **Social Fact:** konteks serangan dan korban di Gaza.
2. **Literature:** penjelasan yang menghubungkan konflik Israel–Palestina dengan agama.
3. **Objection:** kemungkinan bahwa konflik tidak sepenuhnya didasari agama dan terdapat dimensi sumber daya alam.
4. **Argument:** alasan mengapa penguasaan sumber daya alam dapat menjadi bagian dari penjelasan.

Contoh ini hanya menggambarkan bentuk alur argumentasi dalam materi. Klaim faktual dan interpretasinya harus diverifikasi secara independen sebelum digunakan dalam artikel.

## 8. Literature Review

### 8.1 Fungsi Literature Review

Materi menjelaskan bahwa Literature Review (LR):

- Menunjukkan “knowledge roadmap” berdasarkan topik: posisi pengetahuan saat ini.
- Membantu mencegah plagiarisme.
- Membantu penulis menentukan posisi akademiknya.
- Menyediakan teori dan konsep yang dapat mempertajam analisis.

### 8.2 Dua komponen utama: What is known dan What is not known yet

Literature Review perlu memperlihatkan hubungan antara:

- **What is known:** hal-hal yang sudah diketahui atau telah dijelaskan penelitian terdahulu.
- **What is not known yet:** hal-hal yang belum diketahui, belum dijelaskan, atau masih menjadi celah.

Kesenjangan antara keduanya menjadi dasar untuk merumuskan **research gap**.

### 8.3 Model penyusunan Literature Review

Materi menyebut lima model:

1. **Chronological** — menyusun literatur berdasarkan urutan waktu/perkembangan.
2. **Thematic** — menyusun literatur berdasarkan tema.
3. **Theoretical** — menyusun literatur berdasarkan teori atau perspektif teoretis.
4. **Methodological** — menyusun literatur berdasarkan metode penelitian.
5. **Case (Comparative)** — menyusun literatur berdasarkan kasus atau perbandingan kasus.

Pilih model berdasarkan karakter topik dan literatur yang tersedia. Materi tidak menyatakan bahwa semua model harus dipakai sekaligus.

## 9. Theory

Materi menyatakan bahwa teori digunakan untuk menyederhanakan realitas yang kompleks.

Tiga fungsi teori yang ditampilkan:

- **Describe** — mendeskripsikan.
- **Explain** — menjelaskan.
- **Predict** — memprediksi.

Teori dan konsep dalam artikel perlu digunakan sesuai fungsi dan kebutuhan analisis, bukan sekadar dicantumkan sebagai definisi.

## 10. Methods dan Methodology

### 10.1 Perbedaan Methodology dan Method

Materi membedakan keduanya sebagai berikut.

**Methodology:**

- Dasar filosofis penelitian atau perspektif.
- Menentukan metode yang digunakan.
- Berisi asumsi rasional yang mendasari pendekatan penelitian.
- Mengarahkan proses penciptaan pengetahuan baru.

**Method:**

- Prosedur atau instrumen untuk mengumpulkan dan menganalisis data.
- Langkah teknis untuk menghasilkan data.
- Proses terdokumentasi untuk mengelola penelitian.
- Menghasilkan data yang kemudian digunakan untuk membangun pengetahuan.

Ringkasnya: methodology menjelaskan dasar pendekatan penelitian; method menjelaskan prosedur teknis yang dijalankan.

### 10.2 Komponen pelaporan metode

Materi mencantumkan empat komponen berikut.

#### A. Design

Jelaskan:
- Desain penelitian.
- Prosedur.
- Konteks penelitian.

#### B. Source

Jelaskan:
- Siapa atau apa yang diteliti.
- Proses pengumpulan data.

#### C. Measurement

Jelaskan:
- Bagaimana sesuatu diukur.
- Mengapa pengukuran tersebut digunakan.

#### D. Analyze

Jelaskan:
- Prosedur analisis data.
- Cara data diinterpretasikan.

## 11. Results dan Discussion

### 11.1 Hubungan Methods, Results, dan Discussion

Materi menggambarkan hubungan berikut:

- **Methods:** bagaimana pembuktian dilakukan.
- **Results:** bukti atau hasil yang diperoleh (WHAT).
- **Discussion:** interpretasi atas bukti (WHY? SO WHAT?).

Results menyajikan apa yang ditemukan. Discussion menjelaskan arti, konteks, dan implikasi temuan tersebut.

### 11.2 Prinsip Results

Materi memberikan prinsip:

- Fokus pada data, bukan interpretasi pribadi.
- Jika belum melakukan analisis, jangan memasukkan konsep atau teori sebagai seolah-olah sudah digunakan untuk analisis.
- Sajikan data menggunakan tabel atau gambar bila sesuai.
- Hindari pengulangan.
- Susun hasil berdasarkan variabel atau tema.

### 11.3 Penyajian data

Pertimbangkan format penyajian:

- Teks.
- Tabel.
- Gambar atau visualisasi.

Hindari menyajikan informasi yang sama berulang kali dalam teks, tabel, dan gambar tanpa alasan.

### 11.4 Struktur komentar data (Data Commentary Structure)

Materi menyebut empat unsur:

1. **Location elements / summary statement** — kalimat yang menunjukkan lokasi tabel/gambar atau merangkum isi data.
2. **Highlight statement** — soroti temuan utama.
3. **Discussion of implication** — jelaskan implikasi singkat yang memang didukung data.
4. **Fair claims** — buat klaim yang wajar dan sebanding dengan bukti.

### 11.5 Discussion

Materi menyarankan Discussion dimulai dari temuan utama, kemudian mencakup:

- Interpretasi: penyebab, konteks, atau makna.
- Perspektif.
- Theorizing atau pengembangan penjelasan teoretis.
- Meninjau kembali objection atau pertanyaan penelitian.
- Novelty dan contribution.
- Implication dan future research: dari “So What?” menuju “Now What?”.
- Strengths dan limitations.

### 11.6 Enam elemen kunci Discussion

| Elemen | Deskripsi dalam materi | Pertanyaan inti |
|---|---|---|
| Recap | Pernyataan singkat tentang temuan utama. | What did we find? |
| Interpretation | Penjelasan logis dan abstraksi dari data. | Why did we find this? |
| Contextualization | Perbandingan dengan literatur terdahulu dan teori yang ada. | How does this fit with what we know? |
| Novelty | Kontribusi substantif atau pengisian knowledge gap. | What is new here? |
| Implications | Pengaruh terhadap praktik/pengetahuan dan penelitian masa depan. | So what? Now what? |
| Self-Correction | Kekuatan dan keterbatasan. | How reliable is this? |

## 12. Conclusion

### 12.1 Fungsi dan posisi

Conclusion merupakan bagian akhir artikel dan memberikan kesan terakhir kepada pembaca. Materi menyebut perlunya satu kalimat yang merangkum temuan utama.

### 12.2 Elemen Conclusion

Materi menguraikan elemen berikut:

1. **Recap Purpose** — ingatkan pembaca mengapa artikel ditulis.
2. **Address Argument/Hypothesis** — nyatakan kembali argumen tanpa sekadar mengulang kalimat sebelumnya. Untuk artikel dengan hipotesis, sampaikan hasil pengujian hipotesis (diterima atau ditolak) dalam kaitannya dengan penelitian sebelumnya, teori, atau model.
3. **Significance and Contribution** — jelaskan mengapa penelitian penting dan kontribusinya terhadap pengetahuan.
4. **Implications (So What? Now What?)** — jelaskan implikasi, tindakan yang dapat dipertimbangkan, dan penelitian lanjutan, termasuk yang muncul dari keterbatasan penelitian.
5. **Scientific Justification** — berikan justifikasi ilmiah yang jelas mengenai apakah konsep atau model berlaku atau valid.
6. **Global and Specific Conclusions** — berikan kesimpulan umum dan spesifik yang selaras dengan tujuan dalam Introduction.
7. **Exemplifying Findings** — nyatakan pesan utama yang ingin ditunjukkan atau dibuktikan penulis.

Conclusion harus konsisten dengan tujuan penelitian dan temuan yang benar-benar disajikan.

## 13. Abstract

### 13.1 Struktur dan isi

Materi menyajikan empat komponen abstrak:

| Komponen | Isi yang diminta dalam materi |
|---|---|
| Background | Pengingat singkat konteks penelitian dan pernyataan singkat tujuan utama. Identifikasi gap pengetahuan yang ingin diisi. |
| Methods | Ringkas metode utama; jelaskan populasi studi/kriteria inklusi, kelompok studi bila relevan, intervensi/perlakuan secara singkat, dan endpoint utama. Karena ruang terbatas, cantumkan kriteria pembeda yang paling penting, bukan rincian berlebihan. |
| Results | Cantumkan hasil utama, misalnya mean, odds ratio, p-value, dan hasil luaran lainnya. Hasil endpoint utama didahulukan, kemudian hasil sekunder. Hasil harus cukup rinci untuk mendukung kesimpulan. Setiap metode yang disebut harus memiliki hasil yang dilaporkan. |
| Conclusion | Satu kalimat yang merangkum temuan utama. Implikasi untuk penelitian mendatang dapat ditambahkan jika ruang memungkinkan. Kesimpulan harus berhubungan langsung dengan tujuan utama. |

## 14. Referensi dan sumber

### 14.1 Prinsip sumber yang dicantumkan dalam materi

Materi menyarankan:

- Menggunakan referensi yang tersedia secara online.
- Mayoritas sitasi berasal dari jurnal bereputasi.
- Jumlah minimum referensi yang disebutkan: 30 judul untuk artikel dan 40 judul untuk artikel review.
- Mayoritas referensi diterbitkan dalam 10 tahun terakhir.
- Sitasi dilengkapi, termasuk nomor halaman dan DOI.

**Penting:** angka minimum dan batas 10 tahun tersebut adalah arahan dalam slide, bukan aturan universal semua jurnal. Ketentuan jurnal tujuan dan karakter bidang ilmu tetap perlu diperiksa.

### 14.2 Jenis sumber

Materi menyebut:

- Data sekunder dari media yang dianggap bereputasi, dengan contoh NYT, Al-Jazeera, Foreign Policy, dan Kompas.
- Buku dan artikel jurnal.
- Basis/situs artikel seperti JSTOR dan laman jurnal SAGE.

Materi memperingatkan agar berhati-hati menggunakan sumber yang tidak bereputasi, dengan contoh Blogspot, WordPress, dan Wikipedia. Penilaian sumber tetap harus melihat otoritas penulis/penerbit, kualitas bukti, dan kesesuaian sumber dengan klaim.

### 14.3 Catatan keamanan dan legalitas akses sumber

Slide memuat rujukan ke sejumlah situs pengunduhan tidak resmi. Bagian tersebut tidak diubah menjadi instruksi penggunaan. Untuk memperoleh artikel, prioritaskan:

- Situs resmi penerbit atau jurnal.
- Repositori institusi.
- Open-access version yang sah.
- Layanan perpustakaan atau akses institusi.
- Menghubungi penulis untuk salinan yang diizinkan.

## 15. Checklist kerja berdasarkan materi

### Sebelum menulis
- [ ] Tentukan jurnal tujuan dan periksa Aim and Scope.
- [ ] Periksa template, APC, mekanisme submit, dan jadwal penerbitan.
- [ ] Baca literatur secara memadai.
- [ ] Tentukan tema dan fokus topik.
- [ ] Rumuskan pesan/posisi artikel, bukan hanya pertanyaan umum.
- [ ] Periksa disiplin ilmu, criticality, dan positionality.

### Menyusun naskah
- [ ] Buat outline menggunakan template jurnal sejak awal.
- [ ] Susun Introduction dengan Social Fact, Literature, Objection, dan Argument.
- [ ] Susun Literature Review untuk memetakan what is known dan what is not known yet.
- [ ] Jelaskan teori sesuai fungsi describe, explain, atau predict.
- [ ] Bedakan methodology dan method.
- [ ] Jelaskan design, source, measurement, dan analysis.
- [ ] Sajikan Results berbasis data.
- [ ] Susun Discussion dengan recap, interpretation, contextualization, novelty, implications, dan self-correction.
- [ ] Susun Conclusion yang selaras dengan tujuan dan temuan.
- [ ] Pastikan Abstract memuat background, methods, results, dan conclusion.

### Menjaga integritas
- [ ] Verifikasi seluruh referensi, DOI, halaman, data, dan klaim.
- [ ] Jangan menganggap contoh dalam slide sebagai bukti untuk topik penelitian lain.
- [ ] Gunakan AI sebagai asisten, bukan ghostwriter.
- [ ] Pastikan artikel tetap merupakan karya dan tanggung jawab penulis.

## 16. Batas materi sumber

Materi presentasi tidak memberikan protokol rinci untuk semua desain penelitian, prosedur statistik, teknik sampling, strategi pencarian database, atau standar pelaporan spesifik tiap disiplin. Jangan menganggap rincian tersebut telah ditetapkan oleh presentasi ini. Jika diperlukan, lengkapi melalui pedoman metodologi atau standar pelaporan yang relevan dan dinyatakan secara terpisah dari isi presentasi.
