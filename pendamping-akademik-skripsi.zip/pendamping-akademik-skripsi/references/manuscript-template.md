---
title: "Manuscript Template and Writing Guide"
source_file: "Manuscript.docx"
source_type: "Word document"
language: "English and Indonesian"
purpose: "Manuscript structure and section-by-section writing prompts"
---

# Manuscript Template and Writing Guide

> Dokumen ini mengubah isi template Word menjadi Markdown. Teks instruksi dan placeholder dipertahankan maknanya. Bagian bertanda `...` atau placeholder lain harus diisi oleh penulis berdasarkan penelitian yang benar-benar dilakukan.

## 1. Article Title

**Template:**

`[ARTICLE TITLE: specific, informative, shows the message]`

Petunjuk:
- Judul harus spesifik dan informatif.
- Judul menunjukkan pesan utama artikel.
- Judul memuat topik, konteks, dan kata kunci utama.
- Sebaiknya tidak lebih dari 15 kata.

**Isian:**

`[Tulis judul artikel di sini]`

## 2. Authors and Affiliations

**Template:**

- First Author, Second Author
- Affiliation, Department, University, City, Country
- Corresponding author: email@example.com
- ORCID: 0000-0000-0000-0000

**Isian:**

- Penulis: `[Nama penulis sesuai urutan kontribusi dan kebijakan jurnal]`
- Afiliasi: `[Departemen, universitas, kota, negara]`
- Corresponding author: `[Email]`
- ORCID: `[Nomor ORCID masing-masing penulis jika diminta]`

Jangan mengisi nama, afiliasi, email, atau ORCID dengan data contoh. Ganti seluruh placeholder dengan informasi yang benar.

## 3. Abstract

Template meminta abstrak dalam **satu paragraf** dan memberi pengingat:

> Semua yang disebut di Method harus punya hasil di Results.

Struktur isi:

1. **Background:** konteks singkat penelitian.
2. **Objective and gap:** tujuan penelitian dan gap yang hendak dijawab.
3. **Methods:** metode yang benar-benar digunakan.
4. **Results:** hasil utama yang benar-benar ditemukan.
5. **Conclusion:** kesimpulan utama yang berhubungan dengan tujuan penelitian.

**Template isian:**

`[Tulis abstrak satu paragraf dengan urutan Background – Objective and gap – Methods – Results – Conclusion.]`

### 3.1 Keywords

Template menyediakan lima kata kunci:

`keyword 1; keyword 2; keyword 3; keyword 4; keyword 5`

Ganti dengan kata kunci yang paling mewakili topik, konteks, konsep, atau metode artikel sesuai ketentuan jurnal.

## 4. 1. Introduction

**Tujuan:** menunjukkan bahwa penelitian penting, menarik, bermasalah, dan relevan.

Urutan yang digunakan dalam template:

1. Social fact.
2. Literature.
3. Objection.
4. Argument.

### 4.1 1.1 Social Fact

Isi:
- Konteks penelitian.
- Fakta atau data pendukung.
- Sitasi untuk data dan informasi yang digunakan.

**Pertanyaan panduan:**
- Fenomena apa yang menjadi konteks penelitian?
- Apa bukti atau data pendukungnya?
- Mengapa fenomena tersebut penting untuk dibahas?

**Template:**

`[Jelaskan konteks penelitian dan data pendukung dengan sitasi yang dapat diverifikasi.]`

### 4.2 1.2 Literature

Pertanyaan utama dari template:

> Apa jawaban yang sejauh ini diberikan penelitian terdahulu?

Isi:
- Ringkasan terarah atas penelitian terdahulu.
- Penjelasan tentang bagaimana literatur menjawab atau memahami fenomena.
- Sintesis, bukan sekadar daftar ringkasan artikel.

**Template:**

`[Jelaskan temuan dan penjelasan utama dari penelitian terdahulu yang relevan.]`

### 4.3 1.3 Objection and Objective

Isi:
- Gap atau keterbatasan pengetahuan yang ditemukan.
- Keunikan artikel.
- Tujuan penelitian sebagai respons terhadap gap.

Template memberikan pola kalimat:

> "Namun, ... Maka artikel ini bertujuan ..."

Pola tersebut adalah panduan, bukan kalimat wajib. Isi bagian ini harus didukung oleh telaah penelitian terdahulu.

**Template:**

`[Jelaskan apa yang belum terjawab atau perlu dikritisi, kemudian rumuskan tujuan artikel.]`

### 4.4 1.4 Argument and Structure

Isi:
- Dasar logika jawaban sementara atau argumen yang ditawarkan.
- Nilai penelitian.
- Susunan artikel.

**Template:**

`[Jelaskan argumen utama dan dasar logikanya, nilai penelitian, serta organisasi bagian-bagian artikel.]`

## 5. 2. Literature Review

Literature Review berfungsi sebagai peta pengetahuan:

- What is known.
- What is not known yet.
- GAP.

Template menyebut beberapa model penyusunan:
- Chronological.
- Thematic.
- Case/comparative.
- Methodological.
- Theoretical.

Pilih model yang sesuai dengan pertanyaan penelitian dan karakter literatur. Template tidak mewajibkan semua model digunakan sekaligus.

### 5.1 2.1 What is known

**Fungsi:** menjelaskan apa yang telah diketahui atau dijelaskan oleh penelitian sebelumnya.

**Template:**

`[Sintesis pengetahuan dan temuan penelitian terdahulu yang relevan.]`

### 5.2 2.2 What is not known yet (GAP)

**Fungsi:** menjelaskan bagian yang belum diketahui, belum dijelaskan, atau masih menyisakan pertanyaan.

**Template:**

`[Jelaskan gap berdasarkan bukti dari literatur yang telah ditelaah.]`

Jangan menyatakan gap hanya karena belum menemukan artikel secara cepat. Gap harus ditopang oleh proses penelusuran dan pembacaan literatur yang memadai.

### 5.3 2.3 Theoretical Framework

Template menyatakan:

> Teori digunakan untuk menjelaskan, memprediksi, dan menyederhanakan realitas.

**Template:**

`[Jelaskan teori/konsep yang relevan dan bagaimana teori/konsep tersebut digunakan dalam penelitian.]`

## 6. 3. Method

Template membedakan:
- **Methodology:** dasar filosofis penelitian.
- **Method:** prosedur teknis penelitian.

Bagian metode harus melaporkan apa yang benar-benar dilakukan, bukan prosedur yang hanya direncanakan atau direka.

### 6.1 3.1 Research Design

Isi:
- Desain penelitian.
- Prosedur.
- Konteks penelitian.

**Template:**

`[Jelaskan desain penelitian, alasan pemilihannya, prosedur utama, dan konteks penelitian.]`

### 6.2 3.2 Data Source

Isi:
- Siapa atau apa yang diteliti.
- Sumber data.
- Proses pengumpulan data.

**Template:**

`[Jelaskan objek/subjek atau sumber data dan bagaimana data diperoleh.]`

### 6.3 3.3 Measurement

Isi:
- Bagaimana pengukuran dilakukan.
- Mengapa ukuran atau indikator tersebut digunakan.

**Template:**

`[Jelaskan variabel/indikator atau cara pengukuran, definisi operasional jika relevan, serta alasan pemilihannya.]`

Catatan: jika penelitian tidak menggunakan pengukuran kuantitatif, sesuaikan isi subbagian ini dengan prosedur pengumpulan atau pengorganisasian data yang benar-benar digunakan. Periksa juga apakah struktur ini cocok dengan pedoman jurnal.

### 6.4 3.4 Data Analysis

Isi:
- Prosedur analisis data.
- Cara hasil analisis diinterpretasikan.

**Template:**

`[Jelaskan tahapan analisis data secara transparan dan cukup rinci agar pembaca memahami bagaimana hasil diperoleh.]`

## 7. 4. Results

Prinsip dalam template:
- Fokus pada data, bukan opini.
- Jangan memasukkan pembahasan teoretis seolah-olah merupakan hasil data.
- Susun berdasarkan variabel atau tema.
- Hindari pengulangan.

### 7.1 4.1 [Finding 1]

Template memberi struktur komentar data:

1. Kalimat pengantar yang menunjuk tabel atau gambar.
2. Soroti temuan utama.
3. Berikan implikasi singkat jika memang didukung data.
4. Buat klaim yang wajar.

**Template:**

`[Laporkan temuan pertama berdasarkan data. Rujuk tabel/gambar bila ada, soroti hasil utama, dan hindari klaim yang melampaui data.]`

### 7.2 4.2 [Finding 2]

**Template:**

`[Laporkan temuan kedua berdasarkan data dengan struktur yang konsisten.]`

Tambahkan subbagian temuan sesuai kebutuhan penelitian dan aturan jurnal. Jangan mempertahankan placeholder `[Finding 1]` atau `[Finding 2]` pada naskah final.

## 8. 5. Discussion

Template meminta Discussion dimulai dari temuan utama, kemudian membahas:

1. **Interpretation (WHY?)** — mengapa temuan tersebut muncul atau apa maknanya.
2. **Contextualization** — hubungan temuan dengan literatur dan teori sebelumnya.
3. **Novelty** — apa hal baru atau kontribusi artikel.
4. **Implications (SO WHAT? NOW WHAT?)** — mengapa temuan penting dan apa tindak lanjutnya.
5. **Limitations** — keterbatasan penelitian.

Tabel panduan dalam dokumen sumber:

| Element | Pertanyaan panduan |
|---|---|
| Recap | What did we find? |
| Interpretation | Why did we find this? |
| Contextualization | How does this fit with what we know? |
| Novelty | What is new here? |
| Implications | So what? Now what? |
| Self-correction | Strengths and limitations |

**Instruksi template:** tulis setiap elemen sebagai paragraf utuh pada bagian Discussion, lalu hapus tabel panduan dari naskah final.

**Template penulisan:**

`[Tulis paragraf recap temuan utama.]`

`[Tulis interpretasi temuan dan jelaskan alasan atau maknanya.]`

`[Bandingkan dan hubungkan temuan dengan penelitian terdahulu serta teori.]`

`[Jelaskan novelty dan kontribusi artikel.]`

`[Jelaskan implikasi teoretis/praktis dan arah penelitian berikutnya.]`

`[Jelaskan kekuatan dan keterbatasan penelitian.]`

## 9. 6. Conclusion

Conclusion adalah bagian terakhir artikel. Template menegaskan bahwa kesimpulan tidak boleh sekadar mengulang isi pembahasan.

Isi yang perlu dicakup:
- Jawab kembali argumen atau hipotesis.
- Tegaskan signifikansi dan kontribusi.
- Rumuskan implikasi dan penelitian lanjutan.
- Pastikan kesimpulan selaras dengan tujuan dalam Introduction.

**Template:**

`[Tuliskan kesimpulan yang menjawab tujuan/argumen penelitian, menegaskan temuan dan kontribusi, serta menyampaikan implikasi atau arah riset lanjutan secara proporsional.]`

## 10. References

Instruksi dalam template:
- Gunakan satu gaya sitasi sesuai ketentuan jurnal.
- Lengkapi informasi halaman dan DOI.
- Mayoritas referensi berasal dari jurnal bereputasi dan terbit dalam 10 tahun terakhir.
- Template menyebut penggunaan Zotero dengan gaya APA 7th.

**Contoh format yang dicantumkan:**

`Author, A. A. (Year). Title of article. Journal Name, volume(issue), pages. https://doi.org/xxxx`

**Catatan:** APA 7th adalah contoh gaya yang disebut dalam template. Jika jurnal tujuan mewajibkan gaya lain, ikuti author guidelines jurnal tersebut. Periksa keberadaan sumber, metadata bibliografi, halaman, dan DOI sebelum naskah dikirim.

## 11. Final manuscript checklist

### Struktur
- [ ] Judul spesifik, informatif, menunjukkan pesan artikel, dan idealnya tidak lebih dari 15 kata.
- [ ] Nama penulis dan afiliasi sudah benar.
- [ ] Informasi corresponding author dan ORCID sudah benar jika diperlukan.
- [ ] Abstract terdiri dari satu paragraf.
- [ ] Keywords sudah diisi.
- [ ] Introduction memuat Social Fact, Literature, Objection and Objective, Argument and Structure.
- [ ] Literature Review menjelaskan what is known, gap, dan theoretical framework jika relevan.
- [ ] Method melaporkan desain, sumber data, measurement, dan analisis.
- [ ] Results menyajikan temuan berdasarkan data.
- [ ] Discussion membahas recap, interpretation, contextualization, novelty, implications, dan limitations.
- [ ] Conclusion selaras dengan tujuan dan temuan.
- [ ] References menggunakan satu gaya sitasi yang konsisten.

### Konsistensi dan integritas
- [ ] Setiap metode yang disebut dalam Abstract memiliki hasil yang dilaporkan di Results.
- [ ] Setiap klaim faktual memiliki sumber atau bukti yang memadai.
- [ ] Gap didukung oleh literatur yang benar-benar ditelaah.
- [ ] Hasil tidak dicampuradukkan dengan opini atau interpretasi yang belum dibuktikan.
- [ ] Discussion tidak membuat klaim yang melampaui temuan.
- [ ] Placeholder dan tabel instruksi telah dihapus dari naskah final.
- [ ] Referensi, halaman, DOI, dan metadata telah diverifikasi.
- [ ] Format akhir mengikuti template dan author guidelines jurnal tujuan.

## 12. Catatan batas penggunaan template

Template ini memberikan kerangka umum. Template tidak menetapkan secara rinci seluruh pilihan metodologi, teknik sampling, instrumen, prosedur statistik, atau standar pelaporan untuk setiap bidang ilmu. Penulis harus menyesuaikan bagian-bagiannya dengan desain penelitian yang benar-benar digunakan dan persyaratan jurnal tujuan.
